from enum import Enum

class Rol(Enum):
    ESTUDIANTE = "Estudiante"
    MAESTRO = "Maestro"
    COORDINADOR = "Coordinador"