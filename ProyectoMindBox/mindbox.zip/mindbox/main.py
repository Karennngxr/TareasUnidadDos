from menu.menu import Menu

menu = Menu()
menu.login()